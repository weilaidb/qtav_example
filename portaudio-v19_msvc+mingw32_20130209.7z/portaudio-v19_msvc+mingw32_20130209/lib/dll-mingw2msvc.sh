dlltool -m i386 -d libportaudio-2.dll.def -l portaudio.lib -D libportaudio-2.dll
